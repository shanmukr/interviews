print "Choose the below options : \n\t\t\tRead\n\t\t\tAdd\n\t\t\tDelete\n"
input = gets.strip.downcase

class AddDelete

  def get_data
    my_data = Hash.new
    my_data["Projects"] = {}
    resume = File.open("shanmukhareddy_resume.json", "r")
      lines = resume.readlines
      for i in lines
        if i =~ /"Project\s+Name".*\s+"(.*)".*/i
          project_name = $1
					my_data["Projects"][project_name] = {}
        elsif i =~ /"(Description)".*\s+"(.*)".*/i
					my_data["Projects"][project_name][$1] = $2 
        elsif i =~ /"(Responsibilities)".*\s+"(.*)".*/i
          resp = $2.split(',')
          resp = resp.size > 1 ? resp : resp[0]
					my_data["Projects"][project_name][$1] = resp
        elsif i =~ /"(Platform)".*\s+"(.*)".*/i
					my_data["Projects"][project_name][$1] = $2
        elsif i =~ /"(Technology)".*\s+"(.*)".*/i
          #tech = $2.split(',')
          #tech = tech.size > 1 ? tech : tech[0]
					my_data["Projects"][project_name][$1] = $2.split(',')
        elsif i =~ /"(.*)".*\s+"(.*)"/
          my_data[$1] = $2.split(',')
        end
      end
    resume.close
    return my_data
  end

	def read
	  resume_data = get_data()
	end

	def add
	  resume_data = get_data()
		return resume_data
	end

	def delete
	  resume_data = get_data()
	end

end


def check_for_validation(option, data) 
	if option == "phone"
	  if data =~ /\d[10]/
		  return true
		end
  elsif option == 'email'
    if data =~ /.*@\w+.com/
		  return true
	  end
	end
end

def add_data(aa, option, data)
  aa[option.capitalize] << data
  print aa,"\n"
end

obj = AddDelete.new

if input == "read"
  aa = obj.read
  print aa,"\n"
elsif input == "add"
  aa = obj.add
  print "Choose the below options : \n\t\t\tEmail\n\t\t\tTechnologies\n\t\t\tPhone\n\t\t\tProject\n"
  option = gets.strip.downcase
	if option == "phone"
    print "Enter valid Phone Number : "
    data = gets.strip
		if check_for_validation(option, data) == true
			add_data(aa, option, data)
		else
      print "Given Phone Number '#{data}' is not valid. Please enter valid Phone number\n"
		end
	elsif option == "email"
    print "Enter valid Mail Id : "
    data = gets.strip
		if check_for_validation(option, data) == true
			add_data(aa, option, data)
    else
      print "Given email '#{email}' is not valid. Please enter valid email\n"
    end
	elsif option == "technologies"
    print "Enter Technologies : "
    data = gets.strip
	  add_data(aa, option, data)
	end
else
  print "Choose the valod option #{input}\n"
end
