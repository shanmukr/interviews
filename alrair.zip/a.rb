#!/usr/bin/ruby

hash = Hash.new
hash = {"nu" => {}}
list = [ 1, 2, 3, 4, 5, 6, 10, 1, 11 ]

for i in list
  hash['nu'][i] = { i => i }
	if i == 1
	  hash['nu'][i] = {'t' => 't'}
	end
end
print hash,"\n"



__END__
a = "test"
aa = "Testing in ruby"
if aa=~ /#{a.capitalize}.*/i
  print aa.capitalize,"\n"
else
  print "testfgfgsxgb\n"
end

__END__
f = File.open("aa.txt", "r")
  lines = f.readlines
  aa = File.open("aa.txt", "w")
  for i in lines
    if i =~ /ib/ 
      #aa.write( "\"#{$1}, #{word}\"\n" )
     aa.write("")
		else
     aa.write( i )
    end
  end
	aa.close
f.close

__END__
class Test
  def write_data(word)
    f = File.open("aa.txt", "r")
      lines = f.readlines
      aa = File.open("aa.txt", "w")
      for i in lines
        if i =~ /"(ib)"/ 
          aa.write( "\"#{$1}, #{word}\"\n" )
    		else
         aa.write( i )
        end
      end
    	aa.close
    f.close
  end
end
__END__
obj = Test.new
obj.write_data('sample')

__END__
f = File.open("aa.txt", "r")
  lines = f.readlines
  #f.write( 'lines' )
  #f.print "tesingiii\n"
  aa = File.open("aa.txt", "w")
  for i in lines
    if i =~ /"(ib)"/ 
      aa.write( "\"#{$1}, hi\"\n" )
		else
     aa.write( i )
    end
  end
	aa.close
f.close

__END__
a = "  APPLE,alpha,Apple,apple,BALL,CAT,apple,ball,Ball,Cat,APPLE,cat,dog,DOG,elephant, tag, TAG,Tag"
a = a.split(",")
b = a.map{ |f| f.downcase.strip }
a.each do |d|
  if b.count(d.downcase.strip) > 1
    print "count"
    break
  end 
end

print a 
print "\n"



    #tags_hash = {}
    #tags_list = []
    #all_tags = params[:tag_list].split(",").uniq
    #all_tags.each { |tag| tags_hash[tag.downcase.strip] = tag.strip }
    #tags_hash.each_key{|key| tags_list << tags_hash[key] }
    #params[:tag_list] = tags_list.join(",")
__END__
a = true

if a
  print "hi\n" 
else
  print "hi\n" 
end

__END__
a = "APPLE,alpha,Apple,apple,BALL,CAT,apple,ball,Ball,Cat,APPLE,cat,dog,DOG,elephant, tag, TAG,Tag"
a = a.split(",")
b = {}
a.each { |tag| b[tag.downcase.strip] = tag.strip }


tags = []
b.each_key{|key| tags << b[key] }

print tags
print "\n"


__END__
c = a.map{|f| f.downcase }
c = c.uniq 

a.each do |f|
  unless b.include?(f.downcase)
    b << f
  end
end

print b
print "\n"
